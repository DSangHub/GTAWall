/**
 * Stripe product and price configuration for GTA Wall subscriptions.
 * 
 * Dealers can subscribe to display their website URL on all their vehicle listings.
 * Two plans available:
 * - Monthly: $50/month
 * - Yearly: $500/year (save $100)
 */

export const STRIPE_PRODUCTS = {
  WEBSITE_URL_DISPLAY: {
    name: "GTA Wall — Display Your Website URL",
    description: "Show a clickable link to your dealership website on all your vehicle listings.",
  },
} as const;

export const STRIPE_PRICES = {
  MONTHLY: {
    amount: 5000, // $50.00 in cents
    currency: "cad",
    interval: "month" as const,
    intervalCount: 1,
    label: "$50/month",
  },
  YEARLY: {
    amount: 50000, // $500.00 in cents
    currency: "cad",
    interval: "year" as const,
    intervalCount: 1,
    label: "$500/year",
  },
} as const;

export type PlanType = "monthly" | "yearly";

export function getPriceConfig(plan: PlanType) {
  return plan === "monthly" ? STRIPE_PRICES.MONTHLY : STRIPE_PRICES.YEARLY;
}
