import Stripe from "stripe";
import { Router, raw } from "express";
import { ENV } from "../_core/env";
import { getDb } from "../db";
import { dealerProfiles } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { getPriceConfig, STRIPE_PRODUCTS, type PlanType } from "./products";

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

export { stripe };

/**
 * Create a Stripe Checkout Session for a dealer subscription.
 */
export async function createCheckoutSession(opts: {
  userId: number;
  userEmail: string;
  userName: string | null;
  dealerProfileId: number;
  stripeCustomerId: string | null;
  websiteUrl: string;
  plan: PlanType;
  origin: string;
}) {
  const priceConfig = getPriceConfig(opts.plan);

  // Create or reuse Stripe customer
  let customerId = opts.stripeCustomerId;
  if (!customerId) {
    const customer = await stripe.customers.create({
      email: opts.userEmail,
      name: opts.userName || undefined,
      metadata: {
        user_id: opts.userId.toString(),
        dealer_profile_id: opts.dealerProfileId.toString(),
      },
    });
    customerId = customer.id;

    // Save customer ID to dealer profile
    const db = await getDb();
    if (db) {
      await db
        .update(dealerProfiles)
        .set({ stripeCustomerId: customerId })
        .where(eq(dealerProfiles.id, opts.dealerProfileId));
    }
  }

  // Create checkout session with subscription mode
  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    mode: "subscription",
    allow_promotion_codes: true,
    client_reference_id: opts.userId.toString(),
    metadata: {
      user_id: opts.userId.toString(),
      dealer_profile_id: opts.dealerProfileId.toString(),
      plan: opts.plan,
      website_url: opts.websiteUrl,
    },
    line_items: [
      {
        price_data: {
          currency: priceConfig.currency,
          product_data: {
            name: STRIPE_PRODUCTS.WEBSITE_URL_DISPLAY.name,
            description: STRIPE_PRODUCTS.WEBSITE_URL_DISPLAY.description,
          },
          unit_amount: priceConfig.amount,
          recurring: {
            interval: priceConfig.interval,
            interval_count: priceConfig.intervalCount,
          },
        },
        quantity: 1,
      },
    ],
    success_url: `${opts.origin}/dealer-subscription?success=true&plan=${opts.plan}`,
    cancel_url: `${opts.origin}/dealer-subscription?canceled=true`,
  });

  return session;
}

/**
 * Handle Stripe webhook events.
 */
export function createStripeWebhookRouter() {
  const router = Router();

  // Webhook endpoint — must use raw body for signature verification
  router.post(
    "/webhook",
    raw({ type: "application/json" }),
    async (req, res) => {
      const sig = req.headers["stripe-signature"];
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

      if (!sig || !webhookSecret) {
        console.error("[Stripe Webhook] Missing signature or webhook secret");
        res.setHeader("Content-Type", "application/json");
        return res.status(400).json({ error: "Missing signature" });
      }

      let event: Stripe.Event;

      try {
        event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
      } catch (err: any) {
        console.error("[Stripe Webhook] Signature verification failed:", err.message);
        res.setHeader("Content-Type", "application/json");
        return res.status(400).json({ error: `Webhook Error: ${err.message}` });
      }

      // Handle test events (both sandbox and live test events)
      if (event.id.startsWith("evt_test_") || event.type === "payment_intent.succeeded" && !(event.data.object as any).metadata?.user_id) {
        console.log("[Stripe Webhook] Test event detected, returning verification response");
        res.setHeader("Content-Type", "application/json");
        return res.status(200).json({ verified: true });
      }

      console.log(`[Stripe Webhook] Received event: ${event.type} (${event.id})`);

      try {
        switch (event.type) {
          case "checkout.session.completed": {
            const session = event.data.object as Stripe.Checkout.Session;
            await handleCheckoutCompleted(session);
            break;
          }
          case "customer.subscription.updated": {
            const subscription = event.data.object as Stripe.Subscription;
            await handleSubscriptionUpdated(subscription);
            break;
          }
          case "customer.subscription.deleted": {
            const subscription = event.data.object as Stripe.Subscription;
            await handleSubscriptionDeleted(subscription);
            break;
          }
          case "invoice.paid": {
            const invoice = event.data.object as Stripe.Invoice;
            console.log(`[Stripe Webhook] Invoice paid: ${invoice.id}`);
            break;
          }
          default:
            console.log(`[Stripe Webhook] Unhandled event type: ${event.type}`);
        }
      } catch (err) {
        console.error(`[Stripe Webhook] Error processing ${event.type}:`, err);
        // Still return 200 to prevent Stripe from retrying
      }

      res.setHeader("Content-Type", "application/json");
      return res.status(200).json({ received: true });
    }
  );

  return router;
}

/**
 * Handle successful checkout — activate the subscription.
 */
async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  const dealerProfileId = session.metadata?.dealer_profile_id;
  const plan = session.metadata?.plan as PlanType | undefined;
  const websiteUrl = session.metadata?.website_url;
  const subscriptionId = session.subscription as string | null;

  if (!dealerProfileId || !plan) {
    console.error("[Stripe Webhook] Missing metadata in checkout session");
    return;
  }

  const db = await getDb();
  if (!db) return;

  const now = new Date();
  const endDate = new Date(now);
  if (plan === "monthly") {
    endDate.setMonth(endDate.getMonth() + 1);
  } else {
    endDate.setFullYear(endDate.getFullYear() + 1);
  }

  await db
    .update(dealerProfiles)
    .set({
      subscriptionPlan: plan,
      subscriptionStartDate: now,
      subscriptionEndDate: endDate,
      stripeSubscriptionId: subscriptionId,
      websiteUrl: websiteUrl || undefined,
    })
    .where(eq(dealerProfiles.id, parseInt(dealerProfileId)));

  console.log(
    `[Stripe Webhook] Subscription activated for dealer ${dealerProfileId}: ${plan} plan`
  );
}

/**
 * Handle subscription updates (e.g., plan changes, renewals).
 */
async function handleSubscriptionUpdated(subscription: Stripe.Subscription) {
  const db = await getDb();
  if (!db) return;

  // Find dealer by subscription ID
  const dealers = await db
    .select()
    .from(dealerProfiles)
    .where(eq(dealerProfiles.stripeSubscriptionId, subscription.id))
    .limit(1);

  if (dealers.length === 0) return;

  const dealer = dealers[0];

  if (subscription.status === "active") {
    const currentPeriodEnd = new Date((subscription as any).current_period_end * 1000);
    await db
      .update(dealerProfiles)
      .set({ subscriptionEndDate: currentPeriodEnd })
      .where(eq(dealerProfiles.id, dealer.id));
    console.log(`[Stripe Webhook] Subscription renewed for dealer ${dealer.id}`);
  } else if (
    subscription.status === "past_due" ||
    subscription.status === "unpaid"
  ) {
    console.log(
      `[Stripe Webhook] Subscription ${subscription.status} for dealer ${dealer.id}`
    );
  }
}

/**
 * Handle subscription cancellation — deactivate the feature.
 */
async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  const db = await getDb();
  if (!db) return;

  const dealers = await db
    .select()
    .from(dealerProfiles)
    .where(eq(dealerProfiles.stripeSubscriptionId, subscription.id))
    .limit(1);

  if (dealers.length === 0) return;

  await db
    .update(dealerProfiles)
    .set({
      subscriptionPlan: null,
      subscriptionEndDate: null,
      stripeSubscriptionId: null,
    })
    .where(eq(dealerProfiles.id, dealers[0].id));

  console.log(
    `[Stripe Webhook] Subscription canceled for dealer ${dealers[0].id}`
  );
}
