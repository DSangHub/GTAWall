import type { Request, Response } from "express";
import { eq, and, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { vehicles, dealerProfiles, users } from "../../drizzle/schema";
import { notifyOwner } from "../_core/notification";
import { sdk } from "../_core/sdk";

/**
 * Scheduled handler: checks for vehicles expiring within the next 24 hours
 * and notifies:
 * 1. The project owner with a summary of all expiring vehicles
 * 2. Individual dealers about their specific expiring listings
 * 
 * Triggered daily by Heartbeat cron at /api/scheduled/expiring-notifications
 */
export async function expiringNotificationsHandler(req: Request, res: Response) {
  try {
    // Authenticate — only cron callers allowed
    const user = await sdk.authenticateRequest(req);
    if (!user.isCron || !user.taskUid) {
      return res.status(403).json({ error: "cron-only" });
    }

    if (!process.env.DATABASE_URL) {
      return res.status(500).json({ error: "Database not configured" });
    }

    const db = drizzle(process.env.DATABASE_URL);

    // Find vehicles expiring in the next 24 hours
    const now = Date.now();
    const in24Hours = now + 24 * 60 * 60 * 1000;

    const expiringVehicles = await db
      .select({
        id: vehicles.id,
        title: vehicles.title,
        price: vehicles.price,
        auctionDeadline: vehicles.auctionDeadline,
        dealerId: vehicles.dealerId,
        dealerName: dealerProfiles.dealerName,
        dealerPhone: dealerProfiles.phone,
        dealerEmail: users.email,
        ownerName: users.name,
      })
      .from(vehicles)
      .leftJoin(dealerProfiles, eq(vehicles.dealerId, dealerProfiles.userId))
      .leftJoin(users, eq(vehicles.dealerId, users.id))
      .where(
        and(
          eq(vehicles.isActive, true),
          gte(vehicles.auctionDeadline, now),
          lte(vehicles.auctionDeadline, in24Hours)
        )
      );

    if (expiringVehicles.length === 0) {
      return res.json({ ok: true, message: "No expiring vehicles found", count: 0 });
    }

    // Group vehicles by dealer for individual notifications
    const dealerMap = new Map<number, {
      dealerName: string;
      dealerEmail: string | null;
      dealerPhone: string | null;
      vehicles: typeof expiringVehicles;
    }>();

    for (const v of expiringVehicles) {
      if (!dealerMap.has(v.dealerId)) {
        dealerMap.set(v.dealerId, {
          dealerName: v.dealerName || "Unknown Dealer",
          dealerEmail: v.dealerEmail,
          dealerPhone: v.dealerPhone,
          vehicles: [],
        });
      }
      dealerMap.get(v.dealerId)!.vehicles.push(v);
    }

    // Build and send owner notification with full summary
    const vehicleList = expiringVehicles
      .map((v) => {
        const hoursLeft = Math.round((v.auctionDeadline - now) / (1000 * 60 * 60));
        return `• ${v.title} ($${v.price.toLocaleString()}) — ${hoursLeft}h left — Dealer: ${v.dealerName || "Unknown"} (${v.dealerEmail || "no email"})`;
      })
      .join("\n");

    const ownerTitle = `⚠️ ${expiringVehicles.length} Vehicle(s) Expiring in 24 Hours`;
    const dealerBreakdown = Array.from(dealerMap.entries()).map(([_id, d]) => `${d.dealerName} (${d.dealerEmail || d.dealerPhone || "no contact"}): ${d.vehicles.length} vehicle(s)`).join("\n");

    const ownerContent = `The following vehicles on GTA Wall are going to auction within the next 24 hours:\n\n${vehicleList}\n\nThese listings will be removed from the wall once the countdown reaches zero.\n\n--- Dealer Breakdown ---\n${dealerBreakdown}`;

    await notifyOwner({ title: ownerTitle, content: ownerContent });

    // Send individual dealer notifications
    const dealerNotifications: string[] = [];
    const dealerEntries = Array.from(dealerMap.entries());
    for (const [_dealerId, dealer] of dealerEntries) {
      const dealerVehicleList = dealer.vehicles
        .map((v: { title: string; price: number; auctionDeadline: number }) => {
          const hoursLeft = Math.round((v.auctionDeadline - now) / (1000 * 60 * 60));
          return `• ${v.title} ($${v.price.toLocaleString()}) — ${hoursLeft} hours remaining`;
        })
        .join("\n");

      const dealerTitle = `🚨 ${dealer.vehicles.length} of your listing(s) expire in 24 hours`;
      const dealerContent = `Hi ${dealer.dealerName},\n\nThe following vehicle(s) you posted on GTA Wall are going to auction within the next 24 hours:\n\n${dealerVehicleList}\n\nOnce the countdown hits zero, these listings will be removed from the wall and sent to auction.\n\nIf you'd like to keep them on the wall longer, log in to your dashboard and repost them with a new auction date.\n\nContact: ${dealer.dealerEmail || dealer.dealerPhone || "N/A"}`;

      dealerNotifications.push(`${dealer.dealerName}: ${dealer.vehicles.length} vehicle(s)`);

      // Send dealer-specific notification to platform owner for relay to dealer
      // The owner receives per-dealer alerts with contact info to reach out directly
      await notifyOwner({
        title: dealerTitle,
        content: dealerContent,
      });
    }

    return res.json({
      ok: true,
      message: `Notified about ${expiringVehicles.length} expiring vehicle(s) across ${dealerMap.size} dealer(s)`,
      count: expiringVehicles.length,
      dealersNotified: dealerMap.size,
      details: dealerNotifications,
    });
  } catch (error) {
    console.error("[Scheduled] Expiring notifications error:", error);
    return res.status(500).json({
      error: String(error),
      stack: error instanceof Error ? error.stack : undefined,
      context: { url: req.url, taskUid: (req as any).taskUid },
      timestamp: new Date().toISOString(),
    });
  }
}
