import { SEO } from "@/components/SEO";

export default function Terms() {
  return (
    <div className="min-h-screen bg-[#050505]">
      <SEO
        title="Terms of Service — GTA Wall"
        description="Terms of Service for GTA Wall, a pre-auction vehicle marketplace connecting buyers with licensed dealers in the Greater Toronto Area."
        url="https://www.gtawall.com/terms"
      />

      {/* Header */}
      <header className="bg-[#0a0a0a] border-b border-white/5 py-4 px-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <a href="/">
            <img
              src="/manus-storage/logo_3c487b38.png"
              alt="GTA WALL"
              className="h-9 w-auto"
            />
          </a>
          <a
            href="/"
            className="text-zinc-400 hover:text-white text-sm transition-colors"
          >
            ← Back to Wall
          </a>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-6 py-16">
        <h1 className="font-display text-4xl font-bold text-white mb-2">
          Terms of Service
        </h1>
        <p className="text-zinc-500 text-sm mb-12">
          Last updated: July 2026
        </p>

        <div className="space-y-8 text-zinc-300 leading-relaxed">
          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              1. Acceptance of Terms
            </h2>
            <p>
              By accessing or using GTA Wall ("the Platform"), you agree to be bound by these Terms
              of Service. If you do not agree to these terms, you must not use the Platform. We
              reserve the right to modify these terms at any time, and continued use of the Platform
              constitutes acceptance of any changes.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              2. Description of Service
            </h2>
            <p>
              GTA Wall is a pre-auction vehicle marketplace that enables licensed automobile dealers
              to list vehicles that are scheduled to go to auction. Buyers can browse listings, express
              interest, and contact dealers directly. GTA Wall acts solely as an intermediary platform
              and does not participate in, guarantee, or facilitate any transaction between buyers and
              dealers.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              3. User Accounts
            </h2>
            <p>
              To access certain features, you must create an account. You are responsible for
              maintaining the confidentiality of your account credentials and for all activities that
              occur under your account. You must provide accurate and complete information during
              registration and keep your account information up to date. GTA Wall reserves the right
              to suspend or terminate accounts that violate these terms.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              4. Dealer Obligations
            </h2>
            <p>
              Dealers who register on the Platform agree to: (a) provide accurate, truthful, and
              complete information about all listed vehicles, including condition, mileage, and
              pricing; (b) maintain valid dealer licensing as required by their jurisdiction; (c)
              comply with all applicable consumer protection laws, advertising standards, and
              disclosure requirements; (d) respond to buyer inquiries in a timely and professional
              manner; and (e) remove listings promptly when vehicles are no longer available.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              5. Buyer Responsibilities
            </h2>
            <p>
              Buyers acknowledge that: (a) all vehicle information is provided by dealers and GTA
              Wall does not verify listing accuracy; (b) buyers should conduct independent inspections
              and obtain vehicle history reports before making any purchase decision; (c) any
              transaction is solely between the buyer and the dealer; and (d) GTA Wall is not
              responsible for the condition, quality, or legality of any vehicle listed on the
              Platform.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              6. Prohibited Conduct
            </h2>
            <p>
              Users must not: (a) post false, misleading, or fraudulent listings; (b) use the
              Platform for any unlawful purpose; (c) attempt to circumvent security measures or
              access other users' accounts; (d) scrape, harvest, or collect data from the Platform
              without authorization; (e) interfere with the proper functioning of the Platform; or
              (f) engage in harassment, spam, or abusive behavior toward other users.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              7. Fees and Payments
            </h2>
            <p>
              Basic dealer registration is free. Premium features, including website URL display and
              enhanced listing visibility, are available through paid subscriptions. All fees are
              non-refundable unless otherwise stated. GTA Wall reserves the right to change pricing
              at any time with reasonable notice to affected users.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              8. Intellectual Property
            </h2>
            <p>
              All content, design, and functionality of the Platform are owned by GTA Wall and
              protected by applicable intellectual property laws. Dealers retain ownership of their
              listing content but grant GTA Wall a non-exclusive license to display and promote their
              listings on the Platform.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              9. Limitation of Liability
            </h2>
            <p>
              To the maximum extent permitted by law, GTA Wall shall not be liable for any indirect,
              incidental, special, consequential, or punitive damages arising from your use of the
              Platform, including but not limited to loss of profits, data, or business opportunities.
              Our total liability for any claim shall not exceed the amount you paid to GTA Wall in
              the twelve months preceding the claim.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              10. Termination
            </h2>
            <p>
              GTA Wall may suspend or terminate your access to the Platform at any time, with or
              without cause, and with or without notice. Upon termination, your right to use the
              Platform ceases immediately. Provisions that by their nature should survive termination
              (including limitation of liability and intellectual property) shall remain in effect.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              11. Governing Law
            </h2>
            <p>
              These Terms shall be governed by and construed in accordance with the laws of the
              Province of Ontario, Canada, without regard to conflict of law principles. Any disputes
              arising from these Terms or your use of the Platform shall be subject to the exclusive
              jurisdiction of the courts of Ontario.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              12. Contact
            </h2>
            <p>
              If you have questions about these Terms of Service, please contact us through our{" "}
              <a href="/contact" className="text-red-400 hover:text-red-300 underline">
                contact page
              </a>.
            </p>
          </section>

          <section className="border-t border-white/10 pt-8">
            <p className="text-zinc-500 text-sm">
              By using GTA Wall, you acknowledge that you have read, understood, and agree to be
              bound by these Terms of Service.
            </p>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-8 px-6">
        <div className="max-w-4xl mx-auto text-center text-zinc-600 text-sm">
          © {new Date().getFullYear()} GTA Wall — Going To Auction. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
