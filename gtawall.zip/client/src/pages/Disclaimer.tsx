import { SEO } from "@/components/SEO";

export default function Disclaimer() {
  return (
    <div className="min-h-screen bg-[#050505]">
      <SEO
        title="Disclaimer — GTA Wall"
        description="Legal disclaimer for GTA Wall, a pre-auction vehicle marketplace connecting buyers with licensed dealers in the Greater Toronto Area."
        url="https://www.gtawall.com/disclaimer"
      />

      {/* Header */}
      <header className="bg-[#0a0a0a] border-b border-white/5 py-4 px-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <a href="/">
            <img
              src="/manus-storage/logo_3c487b38.png"
              alt="GTA WALL"
              className="h-9 w-auto"
            />
          </a>
          <a
            href="/"
            className="text-zinc-400 hover:text-white text-sm transition-colors"
          >
            ← Back to Wall
          </a>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-6 py-16">
        <h1 className="font-display text-4xl font-bold text-white mb-2">
          Disclaimer
        </h1>
        <p className="text-zinc-500 text-sm mb-12">
          Last updated: July 2026
        </p>

        <div className="space-y-8 text-zinc-300 leading-relaxed">
          <section>
            <p>
              GTA Wall ("the Platform") is a lead generation and advertising service that connects
              vehicle buyers with licensed automobile dealers. GTA Wall does not sell, lease, or
              finance vehicles directly. All vehicle listings, pricing, descriptions, and images are
              provided by third-party dealers and are their sole responsibility.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              No Warranty of Accuracy
            </h2>
            <p>
              While we strive to display accurate information, GTA Wall makes no representations or
              warranties regarding the accuracy, completeness, or reliability of any listing content,
              including but not limited to vehicle condition, mileage, pricing, availability, or
              auction dates. All information is subject to change without notice.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              Not a Party to Transactions
            </h2>
            <p>
              GTA Wall is not a party to any transaction between buyers and dealers. Any purchase,
              offer, or agreement is solely between the buyer and the dealer. GTA Wall assumes no
              liability for disputes, misrepresentations, or damages arising from such transactions.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              No Professional Advice
            </h2>
            <p>
              Nothing on this Platform constitutes legal, financial, or automotive advice. Buyers are
              encouraged to conduct independent inspections, obtain vehicle history reports, and seek
              professional guidance before making any purchase decision.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              Dealer Responsibility
            </h2>
            <p>
              Dealers are solely responsible for ensuring their listings comply with all applicable
              laws, including consumer protection regulations, advertising standards, and disclosure
              requirements in their jurisdiction.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              Limitation of Liability
            </h2>
            <p>
              To the fullest extent permitted by law, GTA Wall, its owners, operators, and affiliates
              shall not be liable for any direct, indirect, incidental, or consequential damages
              arising from the use of this Platform or reliance on any information provided herein.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              Geographic Scope
            </h2>
            <p>
              This Platform primarily serves the Greater Toronto Area (GTA) and surrounding regions
              in Ontario, Canada. All transactions are subject to applicable provincial and federal
              laws.
            </p>
          </section>

          <section className="border-t border-white/10 pt-8">
            <p className="text-zinc-500 text-sm">
              If you have questions about this disclaimer, please contact us through the Platform.
            </p>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-8 px-6">
        <div className="max-w-4xl mx-auto text-center text-zinc-600 text-sm">
          © {new Date().getFullYear()} GTA Wall — Going To Auction. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
