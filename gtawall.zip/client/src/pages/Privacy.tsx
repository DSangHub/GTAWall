import { SEO } from "@/components/SEO";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-[#050505]">
      <SEO
        title="Privacy Policy — GTA Wall"
        description="Privacy Policy for GTA Wall, explaining how we collect, use, and protect your personal information on our pre-auction vehicle marketplace."
        url="https://www.gtawall.com/privacy"
      />

      {/* Header */}
      <header className="bg-[#0a0a0a] border-b border-white/5 py-4 px-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <a href="/">
            <img
              src="/manus-storage/logo_3c487b38.png"
              alt="GTA WALL"
              className="h-9 w-auto"
            />
          </a>
          <a
            href="/"
            className="text-zinc-400 hover:text-white text-sm transition-colors"
          >
            ← Back to Wall
          </a>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-6 py-16">
        <h1 className="font-display text-4xl font-bold text-white mb-2">
          Privacy Policy
        </h1>
        <p className="text-zinc-500 text-sm mb-12">
          Last updated: July 2026
        </p>

        <div className="space-y-8 text-zinc-300 leading-relaxed">
          <section>
            <p>
              GTA Wall ("we," "us," or "our") respects your privacy and is committed to protecting
              your personal information. This Privacy Policy explains how we collect, use, disclose,
              and safeguard your information when you use our platform.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              1. Information We Collect
            </h2>
            <h3 className="text-base font-medium text-zinc-200 mb-2">
              Information You Provide
            </h3>
            <p className="mb-4">
              When you create an account, register as a dealer, or contact us, we may collect: your
              name, email address, phone number, business name, business address, and dealer license
              information. Dealers may also provide vehicle listing information including photos,
              descriptions, and pricing.
            </p>
            <h3 className="text-base font-medium text-zinc-200 mb-2">
              Information Collected Automatically
            </h3>
            <p className="mb-4">
              When you use the Platform, we may automatically collect: your IP address, browser type
              and version, operating system, referring URLs, pages visited, time spent on pages, and
              general location data (city/region level).
            </p>
            <h3 className="text-base font-medium text-zinc-200 mb-2">
              Location Data
            </h3>
            <p>
              With your explicit consent, we may collect precise geolocation data from your device to
              provide distance-based vehicle search features. You can revoke location access at any
              time through your browser settings.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              2. How We Use Your Information
            </h2>
            <p>
              We use the information we collect to: (a) provide, maintain, and improve the Platform;
              (b) process dealer registrations and manage accounts; (c) display vehicle listings and
              facilitate connections between buyers and dealers; (d) send transactional communications
              such as account confirmations and subscription updates; (e) send vehicle alert
              notifications you have opted into; (f) provide location-based search functionality;
              (g) analyze usage patterns to improve user experience; and (h) detect and prevent fraud
              or abuse.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              3. Information Sharing
            </h2>
            <p>
              We do not sell your personal information. We may share information with: (a) dealers,
              when you express interest in a vehicle or submit an inquiry; (b) service providers who
              assist us in operating the Platform (payment processing, hosting, analytics); (c) law
              enforcement or regulatory authorities when required by law; and (d) in connection with
              a merger, acquisition, or sale of assets, with appropriate notice to affected users.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              4. Cookies and Tracking
            </h2>
            <p>
              We use cookies and similar technologies to: maintain your session and authentication
              state, remember your preferences, analyze traffic patterns, and improve Platform
              performance. You can control cookie settings through your browser, though disabling
              cookies may affect Platform functionality.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              5. Data Security
            </h2>
            <p>
              We implement appropriate technical and organizational measures to protect your personal
              information against unauthorized access, alteration, disclosure, or destruction. These
              measures include encryption of data in transit, secure server infrastructure, and
              access controls. However, no method of transmission over the Internet is 100% secure,
              and we cannot guarantee absolute security.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              6. Data Retention
            </h2>
            <p>
              We retain your personal information for as long as your account is active or as needed
              to provide services. If you request account deletion, we will remove your personal data
              within 30 days, except where retention is required by law or for legitimate business
              purposes (such as resolving disputes or enforcing agreements).
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              7. Your Rights
            </h2>
            <p>
              Depending on your jurisdiction, you may have the right to: (a) access the personal
              information we hold about you; (b) request correction of inaccurate data; (c) request
              deletion of your data; (d) withdraw consent for data processing; (e) object to certain
              processing activities; and (f) request data portability. To exercise these rights,
              please contact us through our{" "}
              <a href="/contact" className="text-red-400 hover:text-red-300 underline">
                contact page
              </a>.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              8. Third-Party Services
            </h2>
            <p>
              The Platform may integrate with third-party services including payment processors
              (Stripe), mapping services (Google Maps), and authentication providers. These services
              have their own privacy policies, and we encourage you to review them. We are not
              responsible for the privacy practices of third-party services.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              9. Children's Privacy
            </h2>
            <p>
              The Platform is not intended for individuals under 18 years of age. We do not knowingly
              collect personal information from children. If we become aware that we have collected
              data from a child, we will take steps to delete it promptly.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              10. Changes to This Policy
            </h2>
            <p>
              We may update this Privacy Policy from time to time. We will notify you of material
              changes by posting the updated policy on the Platform with a revised "Last updated"
              date. Your continued use of the Platform after changes are posted constitutes acceptance
              of the updated policy.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">
              11. Contact Us
            </h2>
            <p>
              If you have questions or concerns about this Privacy Policy or our data practices,
              please reach out through our{" "}
              <a href="/contact" className="text-red-400 hover:text-red-300 underline">
                contact page
              </a>.
            </p>
          </section>

          <section className="border-t border-white/10 pt-8">
            <p className="text-zinc-500 text-sm">
              This Privacy Policy applies to all users of GTA Wall, including buyers, dealers, and
              visitors, within the Province of Ontario, Canada and is governed by applicable Canadian
              privacy legislation including PIPEDA.
            </p>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-8 px-6">
        <div className="max-w-4xl mx-auto text-center text-zinc-600 text-sm">
          © {new Date().getFullYear()} GTA Wall — Going To Auction. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
