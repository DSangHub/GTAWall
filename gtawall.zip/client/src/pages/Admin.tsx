import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { SEO } from "@/components/SEO";
import {
  Users,
  Car,
  DollarSign,
  Activity,
  Shield,
  ArrowLeft,
  ToggleLeft,
  ToggleRight,
  Globe,
  Phone,
  MapPin,
} from "lucide-react";

export default function Admin() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const stats = trpc.admin.stats.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });
  const dealers = trpc.admin.dealers.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });
  const vehicles = trpc.admin.vehicles.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const toggleVehicle = trpc.admin.toggleVehicle.useMutation({
    onSuccess: () => {
      vehicles.refetch();
      stats.refetch();
      toast.success("Vehicle status updated");
    },
  });

  const updateLimit = trpc.admin.updateDealerLimit.useMutation({
    onSuccess: () => {
      dealers.refetch();
      toast.success("Dealer limit updated");
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-white/60 font-mono">AUTHENTICATING...</div>
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <Card className="bg-[#1a1a1a] border-red-900/50 max-w-md">
          <CardContent className="p-8 text-center">
            <Shield className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Access Denied</h2>
            <p className="text-white/60 mb-4">
              You must be an admin to access this panel.
            </p>
            <Button
              variant="outline"
              onClick={() => navigate("/")}
              className="border-white/20 text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      <SEO
        title="Admin Panel | GTA Wall"
        description="GTA Wall admin panel — manage dealers, moderate listings, and monitor platform activity."
        url="https://www.gtawall.com/admin"
      />
      {/* Header */}
      <div className="border-b border-white/10 bg-[#0f0f0f]">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-red-500" />
            <h1 className="text-xl font-bold font-['Oswald'] uppercase tracking-wider">
              Admin Panel
            </h1>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate("/")}
            className="border-white/20 text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Site
          </Button>
        </div>
      </div>

      <div className="container py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-[#1a1a1a] border-white/10">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/20">
                <Users className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <p className="text-sm text-white/60">Total Dealers</p>
                <p className="text-2xl font-bold text-white">
                  {stats.data?.totalDealers ?? "—"}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[#1a1a1a] border-white/10">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/20">
                <Car className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <p className="text-sm text-white/60">Active Vehicles</p>
                <p className="text-2xl font-bold text-white">
                  {stats.data?.activeVehicles ?? "—"}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[#1a1a1a] border-white/10">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/20">
                <Activity className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <p className="text-sm text-white/60">Total Listings</p>
                <p className="text-2xl font-bold text-white">
                  {stats.data?.totalVehicles ?? "—"}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[#1a1a1a] border-white/10">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/20">
                <DollarSign className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <p className="text-sm text-white/60">Active Subscriptions</p>
                <p className="text-2xl font-bold text-white">
                  {stats.data?.activeSubscriptions ?? "—"}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="dealers" className="space-y-4">
          <TabsList className="bg-[#1a1a1a] border border-white/10">
            <TabsTrigger value="dealers" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Dealers
            </TabsTrigger>
            <TabsTrigger value="vehicles" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              Vehicles
            </TabsTrigger>
          </TabsList>

          {/* Dealers Tab */}
          <TabsContent value="dealers">
            <Card className="bg-[#1a1a1a] border-white/10">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Registered Dealers ({dealers.data?.length ?? 0})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {dealers.isLoading ? (
                  <p className="text-white/60 font-mono text-sm">Loading...</p>
                ) : dealers.data?.length === 0 ? (
                  <p className="text-white/60">No dealers registered yet.</p>
                ) : (
                  <div className="space-y-3">
                    {dealers.data?.map((dealer) => (
                      <div
                        key={dealer.id}
                        className="p-4 rounded-lg bg-[#0f0f0f] border border-white/5 flex flex-col md:flex-row md:items-center gap-3 justify-between"
                      >
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white">
                              {dealer.dealerName}
                            </span>
                            {dealer.subscriptionPlan && (
                              <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                {dealer.subscriptionPlan}
                              </Badge>
                            )}
                          </div>
                          <div className="flex flex-wrap gap-3 text-sm text-white/50">
                            <span className="flex items-center gap-1">
                              <Phone className="w-3 h-3" />
                              {dealer.phone}
                            </span>
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              {dealer.address}
                            </span>
                            {dealer.websiteUrl && (
                              <span className="flex items-center gap-1">
                                <Globe className="w-3 h-3" />
                                <a
                                  href={dealer.websiteUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-blue-400 hover:underline"
                                >
                                  {dealer.websiteUrl}
                                </a>
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-white/40">
                            User: {dealer.userName || "—"} ({dealer.userEmail || "no email"})
                            {" | "}Max Vehicles: {dealer.maxVehicles}
                            {dealer.subscriptionEndDate && (
                              <>
                                {" | "}Sub expires:{" "}
                                {new Date(dealer.subscriptionEndDate).toLocaleDateString()}
                              </>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <select
                            className="bg-[#1a1a1a] border border-white/20 rounded px-2 py-1 text-sm text-white"
                            value={dealer.maxVehicles}
                            onChange={(e) =>
                              updateLimit.mutate({
                                dealerProfileId: dealer.id,
                                maxVehicles: parseInt(e.target.value),
                              })
                            }
                          >
                            {[1, 2, 3, 5, 10, 15, 20, 50].map((n) => (
                              <option key={n} value={n}>
                                {n} vehicles
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Vehicles Tab */}
          <TabsContent value="vehicles">
            <Card className="bg-[#1a1a1a] border-white/10">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Car className="w-5 h-5" />
                  All Vehicles ({vehicles.data?.length ?? 0})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {vehicles.isLoading ? (
                  <p className="text-white/60 font-mono text-sm">Loading...</p>
                ) : vehicles.data?.length === 0 ? (
                  <p className="text-white/60">No vehicles posted yet.</p>
                ) : (
                  <div className="space-y-3">
                    {vehicles.data?.map((vehicle) => {
                      const isExpired = vehicle.auctionDeadline < Date.now();
                      return (
                        <div
                          key={vehicle.id}
                          className={`p-4 rounded-lg bg-[#0f0f0f] border flex flex-col md:flex-row md:items-center gap-3 justify-between ${
                            !vehicle.isActive
                              ? "border-red-900/30 opacity-60"
                              : isExpired
                              ? "border-amber-900/30"
                              : "border-white/5"
                          }`}
                        >
                          <div className="flex items-center gap-3 flex-1">
                            {vehicle.imageUrl && (
                              <img
                                src={vehicle.imageUrl}
                                alt={vehicle.title}
                                className="w-16 h-12 object-cover rounded"
                              />
                            )}
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-white">
                                  {vehicle.title}
                                </span>
                                {!vehicle.isActive && (
                                  <Badge variant="destructive" className="text-xs">
                                    Inactive
                                  </Badge>
                                )}
                                {isExpired && vehicle.isActive && (
                                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-xs">
                                    Expired
                                  </Badge>
                                )}
                                {vehicle.isPremium && (
                                  <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-xs">
                                    Premium
                                  </Badge>
                                )}
                              </div>
                              <div className="text-sm text-white/50">
                                ${vehicle.price.toLocaleString()} | Dealer:{" "}
                                {vehicle.dealerName || "Unknown"} |{" "}
                                {vehicle.make} {vehicle.model} {vehicle.year}
                              </div>
                              <div className="text-xs text-white/40">
                                Deadline:{" "}
                                {new Date(vehicle.auctionDeadline).toLocaleString()}
                                {" | "}Posted:{" "}
                                {new Date(vehicle.createdAt).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                          <div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                toggleVehicle.mutate({
                                  vehicleId: vehicle.id,
                                  isActive: !vehicle.isActive,
                                })
                              }
                              className={`border-white/20 text-white hover:bg-white/10 ${
                                vehicle.isActive
                                  ? "hover:border-red-500 hover:text-red-400"
                                  : "hover:border-green-500 hover:text-green-400"
                              }`}
                            >
                              {vehicle.isActive ? (
                                <>
                                  <ToggleRight className="w-4 h-4 mr-1" />
                                  Deactivate
                                </>
                              ) : (
                                <>
                                  <ToggleLeft className="w-4 h-4 mr-1" />
                                  Activate
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
