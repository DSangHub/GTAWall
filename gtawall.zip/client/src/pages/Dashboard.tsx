import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { PLACEHOLDER_IMAGE } from "@/lib/vehicles";
import { SEO } from "@/components/SEO";
import { useRef, useState } from "react";

const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_LOGO_SIZE = 2 * 1024 * 1024; // 2MB

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1]);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function Dashboard() {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const { data: myVehicles = [], isLoading } = trpc.vehicles.myListings.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );
  const { data: dealerProfile } = trpc.dealer.profile.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );
  const utils = trpc.useUtils();
  const logoInputRef = useRef<HTMLInputElement>(null);
  const [logoUploading, setLogoUploading] = useState(false);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      toast.error("Please select a JPG, PNG, or WebP image");
      return;
    }
    if (file.size > MAX_LOGO_SIZE) {
      toast.error("Logo must be under 2MB");
      return;
    }
    setLogoUploading(true);
    try {
      const base64 = await readFileAsBase64(file);
      await utils.client.dealer.uploadLogo.mutate({
        imageBase64: base64,
        mimeType: file.type,
      });
      utils.dealer.profile.invalidate();
      utils.vehicles.list.invalidate();
      toast.success("Logo updated!");
    } catch {
      toast.error("Failed to upload logo. Please try again.");
    } finally {
      setLogoUploading(false);
      e.target.value = "";
    }
  };

  const deleteMutation = trpc.vehicles.delete.useMutation({
    onSuccess: () => {
      utils.vehicles.myListings.invalidate();
      utils.vehicles.list.invalidate();
      toast.success("Vehicle removed from the wall.");
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="animate-pulse text-zinc-500">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-6">
          <h1 className="font-display text-3xl font-bold text-white mb-4">
            Dealer Dashboard
          </h1>
          <p className="text-zinc-400 mb-6">
            Sign in to manage your vehicle listings on the GTA Wall.
          </p>
          <a
            href={getLoginUrl()}
            className="inline-block bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-3 rounded-xl transition-all"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505]">
      <SEO
        title="Dealer Dashboard — Manage Your Listings | GTA Wall"
        description="Manage your vehicle listings on GTA Wall. Post, edit, and track your vehicles going to auction."
        url="https://www.gtawall.com/dashboard"
      />
      {/* Header */}
      <header className="bg-[#0a0a0a] border-b border-white/5 py-4 px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <a href="/">
              <img
                src="/manus-storage/logo_3c487b38.png"
                alt="GTA WALL"
                className="h-9 w-auto"
              />
            </a>
            <span className="text-zinc-600">|</span>
            <h1 className="text-white font-semibold">My Listings</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-zinc-400 text-sm">{user?.name || user?.email}</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => logout()}
              className="border-white/10 text-zinc-300 hover:bg-white/5"
            >
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-6xl mx-auto px-6 py-10">
        {/* Dealer Profile / Logo Section */}
        {dealerProfile && (
          <div className="mb-8 bg-[#0a0a0a] border border-white/5 rounded-xl p-5">
            <div className="flex items-center gap-4">
              <div
                onClick={() => logoInputRef.current?.click()}
                className="relative w-14 h-14 rounded-full bg-[#1a1a1a] border-2 border-dashed border-white/20 flex items-center justify-center cursor-pointer hover:border-red-500/50 transition-colors overflow-hidden group"
              >
                {dealerProfile.logoUrl ? (
                  <>
                    <img src={dealerProfile.logoUrl} alt="Logo" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                      </svg>
                    </div>
                  </>
                ) : (
                  <svg className="w-5 h-5 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z" />
                  </svg>
                )}
                {logoUploading && (
                  <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <p className="text-white font-semibold">{dealerProfile.dealerName}</p>
                <p className="text-zinc-500 text-xs">
                  {dealerProfile.logoUrl ? "Click logo to change" : "Click to upload your dealer logo"}
                </p>
              </div>
              {/* Location status */}
              <div className="flex items-center gap-2">
                {dealerProfile.latitude ? (
                  <span className="text-xs text-emerald-400 flex items-center gap-1">
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    Location set
                  </span>
                ) : (
                  <button
                    onClick={async () => {
                      try {
                        const resp = await fetch(`/api/geocode?address=${encodeURIComponent(dealerProfile.address)}`);
                        if (!resp.ok) throw new Error();
                        const { lat, lng } = await resp.json();
                        await utils.client.dealer.updateLocation.mutate({ latitude: lat, longitude: lng });
                        utils.dealer.profile.invalidate();
                        toast.success("Location updated from your address!");
                      } catch {
                        toast.error("Could not geocode your address. Please update it.");
                      }
                    }}
                    className="text-xs text-yellow-400 hover:text-yellow-300 flex items-center gap-1 transition-colors"
                  >
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    Set location
                  </button>
                )}
              </div>
            </div>
            <input
              ref={logoInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={handleLogoUpload}
            />
          </div>
        )}

        {/* Subscription upsell banner */}
        <a
          href="/dealer-subscription"
          className="block mb-8 bg-gradient-to-r from-blue-900/30 to-purple-900/30 border border-blue-500/20 rounded-xl p-5 hover:border-blue-500/40 transition-all group"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                </svg>
              </div>
              <div>
                <p className="text-white font-semibold">Display Your Website URL</p>
                <p className="text-zinc-400 text-sm">Get a clickable link on all your listings — $50/month or $500/year</p>
              </div>
            </div>
            <span className="text-blue-400 text-sm font-medium group-hover:text-blue-300 transition-colors">
              Learn More →
            </span>
          </div>
        </a>

        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-white">Your Vehicles</h2>
            <p className="text-zinc-500 text-sm mt-1">
              {myVehicles.length} listing{myVehicles.length !== 1 ? "s" : ""}
            </p>
          </div>
          <a
            href="/"
            className="text-sm text-red-400 hover:text-red-300 transition-colors"
          >
            ← Back to Wall
          </a>
        </div>

        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2].map((i) => (
              <div
                key={i}
                className="rounded-xl bg-[#111] ring-1 ring-white/5 p-4 animate-pulse"
              >
                <div className="h-32 bg-zinc-800 rounded-lg mb-3" />
                <div className="h-4 bg-zinc-800 rounded w-2/3 mb-2" />
                <div className="h-4 bg-zinc-800 rounded w-1/3" />
              </div>
            ))}
          </div>
        )}

        {!isLoading && myVehicles.length === 0 && (
          <div className="text-center py-20 bg-[#0a0a0a] rounded-xl border border-white/5">
            <p className="text-zinc-500 text-lg mb-4">
              You haven't posted any vehicles yet.
            </p>
            <a
              href="/"
              className="inline-block bg-red-600 hover:bg-red-700 text-white font-bold px-6 py-2.5 rounded-lg transition-all"
            >
              Post Your First Vehicle
            </a>
          </div>
        )}

        {!isLoading && myVehicles.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {myVehicles.map((vehicle) => {
              const isExpired = vehicle.auctionDeadline < Date.now();
              const daysLeft = Math.max(
                0,
                Math.ceil((vehicle.auctionDeadline - Date.now()) / 86400000)
              );

              return (
                <div
                  key={vehicle.id}
                  className={`rounded-xl bg-[#111] ring-1 ${
                    vehicle.isActive && !isExpired
                      ? "ring-white/10"
                      : "ring-red-500/20 opacity-60"
                  } overflow-hidden`}
                >
                  <div className="flex">
                    <img
                      src={vehicle.imageUrl || PLACEHOLDER_IMAGE}
                      alt={vehicle.title}
                      className="w-32 h-28 object-cover"
                    />
                    <div className="flex-1 p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-white font-semibold text-sm truncate">
                            {vehicle.title}
                          </h3>
                          <p className="text-emerald-400 font-mono font-bold text-lg">
                            ${vehicle.price.toLocaleString()}
                          </p>
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                            isExpired
                              ? "bg-red-500/20 text-red-400"
                              : vehicle.isActive
                              ? "bg-emerald-500/20 text-emerald-400"
                              : "bg-zinc-500/20 text-zinc-400"
                          }`}
                        >
                          {isExpired
                            ? "Expired"
                            : vehicle.isActive
                            ? `${daysLeft}d left`
                            : "Inactive"}
                        </span>
                      </div>
                      <div className="mt-3 flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs border-white/10 text-zinc-300 hover:bg-white/5 h-7"
                          onClick={() => {
                            deleteMutation.mutate({ id: vehicle.id });
                          }}
                          disabled={deleteMutation.isPending}
                        >
                          Remove
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
