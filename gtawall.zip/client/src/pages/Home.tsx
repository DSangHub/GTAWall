import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import { SEO } from "@/components/SEO";
import VehicleWall from "@/components/VehicleWall";
import GoneToAuction from "@/components/GoneToAuction";
import DealerSection from "@/components/DealerSection";
import Footer from "@/components/Footer";
import AddVehicleModal from "@/components/AddVehicleModal";
import BuyerAlertModal from "@/components/BuyerAlertModal";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);

  // Fetch vehicles from the API
  const { data: vehicles = [], isLoading } = trpc.vehicles.list.useQuery();

  return (
    <div className="min-h-screen bg-background">
      <SEO
        title="GTA Wall | Going To Auction — Pre-Auction Vehicle Marketplace"
        description="Buy vehicles before they hit auction. GTA dealers post cars, trucks & SUVs going to auction in 5 days. Browse the wall, apply for credit, and save thousands."
        keywords="GTA Wall, going to auction, pre-auction vehicles, buy cars before auction, GTA dealers, used cars Toronto, vehicle auction countdown, apply for credit, dealer credit application, cars going to auction GTA"
        url="https://www.gtawall.com"
      />
      <Navbar
        onOpenModal={() => setIsModalOpen(true)}
        isAuthenticated={isAuthenticated}
        userName={user?.name ?? undefined}
      />
      <Hero onOpenModal={() => setIsModalOpen(true)} />
      <VehicleWall vehicles={vehicles} isLoading={isLoading} onOpenAlertModal={() => setIsAlertModalOpen(true)} />
      <GoneToAuction />
      <DealerSection onOpenModal={() => setIsModalOpen(true)} />
      <Footer />
      <AddVehicleModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        isAuthenticated={isAuthenticated}
      />
      <BuyerAlertModal
        isOpen={isAlertModalOpen}
        onClose={() => setIsAlertModalOpen(false)}
      />
    </div>
  );
}
