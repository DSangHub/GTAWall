import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { SEO } from "@/components/SEO";
import { Helmet } from "react-helmet-async";
import ShareButton from "@/components/ShareButton";

function CountdownTimer({ deadline }: { deadline: number }) {
  const [timeLeft, setTimeLeft] = useState(() => Math.max(0, deadline - Date.now()));

  useEffect(() => {
    const interval = setInterval(() => {
      const remaining = Math.max(0, deadline - Date.now());
      setTimeLeft(remaining);
      if (remaining <= 0) clearInterval(interval);
    }, 1000);
    return () => clearInterval(interval);
  }, [deadline]);

  const days = Math.floor(timeLeft / 86400000);
  const hours = Math.floor((timeLeft % 86400000) / 3600000);
  const minutes = Math.floor((timeLeft % 3600000) / 60000);
  const seconds = Math.floor((timeLeft % 60000) / 1000);

  if (timeLeft <= 0) {
    return <span className="text-red-500 font-bold">EXPIRED</span>;
  }

  return (
    <div className="flex gap-3">
      {[
        { value: days, label: "DAYS" },
        { value: hours, label: "HRS" },
        { value: minutes, label: "MIN" },
        { value: seconds, label: "SEC" },
      ].map((unit) => (
        <div key={unit.label} className="text-center">
          <div className="bg-[#1a1a1a] border border-white/10 rounded-lg px-3 py-2 min-w-[56px]">
            <span className="font-mono text-2xl font-bold text-white">
              {String(unit.value).padStart(2, "0")}
            </span>
          </div>
          <span className="text-[10px] text-zinc-500 tracking-wider mt-1 block">
            {unit.label}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function VehicleDetail() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const vehicleId = parseInt(params.id || "0");

  const { data: vehicle, isLoading, error } = trpc.vehicles.detail.useQuery(
    { id: vehicleId },
    { enabled: vehicleId > 0 }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="animate-pulse text-zinc-500">Loading vehicle...</div>
      </div>
    );
  }

  if (error || !vehicle) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-2">Vehicle Not Found</h1>
          <p className="text-zinc-400 mb-6">This listing may have been removed or expired.</p>
          <Button onClick={() => setLocation("/")} variant="outline" className="border-white/20 text-white hover:bg-white/5">
            Back to Wall
          </Button>
        </div>
      </div>
    );
  }

  const isExpired = vehicle.auctionDeadline <= Date.now();

  // Dynamic SEO meta
  const seoTitle = vehicle.year && vehicle.make && vehicle.model
    ? `${vehicle.year} ${vehicle.make} ${vehicle.model} \u2014 $${vehicle.price.toLocaleString()}`
    : vehicle.title;
  const seoDescription = [
    vehicle.condition,
    vehicle.year,
    vehicle.make,
    vehicle.model,
    vehicle.mileage ? `with ${vehicle.mileage}` : null,
    vehicle.color ? `in ${vehicle.color}` : null,
    `\u2014 $${vehicle.price.toLocaleString()}.`,
    "Going to auction soon on GTA Wall. Apply for credit before it's gone.",
  ].filter(Boolean).join(" ");
  const seoImage = vehicle.imageUrl || "https://www.gtawall.com/manus-storage/hero-banner_7a2a3d1e.jpg";
  const seoUrl = `https://www.gtawall.com/vehicle/${vehicle.id}`;

  // JSON-LD structured data (schema.org/Car)
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Car",
    name: vehicle.title,
    description: vehicle.description || seoDescription,
    image: vehicle.imageUrl || undefined,
    url: seoUrl,
    vehicleIdentificationNumber: vehicle.vin || undefined,
    color: vehicle.color || undefined,
    mileageFromOdometer: vehicle.mileage
      ? { "@type": "QuantitativeValue", value: vehicle.mileage }
      : undefined,
    modelDate: vehicle.year || undefined,
    brand: vehicle.make ? { "@type": "Brand", name: vehicle.make } : undefined,
    model: vehicle.model || undefined,
    itemCondition:
      vehicle.condition === "New"
        ? "https://schema.org/NewCondition"
        : "https://schema.org/UsedCondition",
    offers: {
      "@type": "Offer",
      price: vehicle.price,
      priceCurrency: "CAD",
      availability: isExpired
        ? "https://schema.org/SoldOut"
        : "https://schema.org/InStock",
      seller: vehicle.dealer
        ? {
            "@type": "AutoDealer",
            name: vehicle.dealer.name,
            telephone: vehicle.dealer.phone,
          }
        : undefined,
    },
  };

  return (
    <div className="min-h-screen bg-[#050505]">
      <SEO
        title={seoTitle}
        description={seoDescription}
        keywords={`${vehicle.make || ""} ${vehicle.model || ""}, ${vehicle.year || ""} ${vehicle.make || ""}, going to auction, pre-auction vehicle, GTA Wall, buy before auction`}
        image={seoImage}
        url={seoUrl}
        type="product"
      />
      <Helmet>
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>

      {/* Top nav */}
      <nav className="sticky top-0 z-50 bg-[#050505]/90 backdrop-blur-md border-b border-white/5">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <a href="/" className="flex items-center gap-3">
            <img src="/manus-storage/logo_3c487b38.png" alt="GTA WALL" className="h-8 w-auto" />
          </a>
          <Button
            onClick={() => setLocation("/")}
            variant="outline"
            className="border-white/20 text-white hover:bg-white/5 text-sm"
          >
            ← Back to Wall
          </Button>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Left: Image */}
          <div className="space-y-4">
            <div className="relative aspect-[4/3] bg-[#111] rounded-2xl overflow-hidden border border-white/10">
              {vehicle.imageUrl ? (
                <img
                  src={vehicle.imageUrl}
                  alt={vehicle.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <svg className="w-20 h-20 text-zinc-700" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
              )}
              {vehicle.isPremium && (
                <div className="absolute top-4 left-4 bg-amber-500/90 text-black text-xs font-bold px-3 py-1 rounded-full">
                  FEATURED
                </div>
              )}
              {isExpired && (
                <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                  <span className="text-red-500 font-bold text-3xl tracking-wider">AUCTION ENDED</span>
                </div>
              )}
            </div>
          </div>

          {/* Right: Details */}
          <div className="space-y-6">
            {/* Title & Price */}
            <div>
              <div className="flex items-start justify-between gap-3">
                <h1 className="font-display text-3xl md:text-4xl font-bold text-white mb-2">
                  {vehicle.title}
                </h1>
                <ShareButton
                  title={vehicle.title}
                  url={`/vehicle/${vehicle.id}`}
                />
              </div>
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bold text-emerald-400">
                  ${vehicle.price.toLocaleString()}
                </span>
                {vehicle.condition && (
                  <span className="text-sm text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded">
                    {vehicle.condition}
                  </span>
                )}
              </div>
            </div>

            {/* Countdown */}
            <div className="bg-[#111] border border-white/10 rounded-xl p-5">
              <p className="text-xs text-red-400 font-semibold tracking-wider uppercase mb-3">
                {isExpired ? "Auction Ended" : "Time Remaining Until Auction"}
              </p>
              <CountdownTimer deadline={vehicle.auctionDeadline} />
            </div>

            {/* Specs Grid */}
            <div className="bg-[#111] border border-white/10 rounded-xl p-5">
              <h3 className="text-sm text-zinc-400 font-semibold tracking-wider uppercase mb-4">
                Vehicle Specs
              </h3>
              <div className="grid grid-cols-2 gap-4">
                {vehicle.year && (
                  <div>
                    <span className="text-xs text-zinc-500">Year</span>
                    <p className="text-white font-medium">{vehicle.year}</p>
                  </div>
                )}
                {vehicle.make && (
                  <div>
                    <span className="text-xs text-zinc-500">Make</span>
                    <p className="text-white font-medium">{vehicle.make}</p>
                  </div>
                )}
                {vehicle.model && (
                  <div>
                    <span className="text-xs text-zinc-500">Model</span>
                    <p className="text-white font-medium">{vehicle.model}</p>
                  </div>
                )}
                {vehicle.mileage && (
                  <div>
                    <span className="text-xs text-zinc-500">Mileage</span>
                    <p className="text-white font-medium">{vehicle.mileage}</p>
                  </div>
                )}
                {vehicle.color && (
                  <div>
                    <span className="text-xs text-zinc-500">Color</span>
                    <p className="text-white font-medium">{vehicle.color}</p>
                  </div>
                )}
                {vehicle.vin && (
                  <div>
                    <span className="text-xs text-zinc-500">VIN</span>
                    <p className="text-white font-mono text-sm">{vehicle.vin}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Description */}
            {vehicle.description && (
              <div className="bg-[#111] border border-white/10 rounded-xl p-5">
                <h3 className="text-sm text-zinc-400 font-semibold tracking-wider uppercase mb-3">
                  Description
                </h3>
                <p className="text-zinc-300 leading-relaxed whitespace-pre-wrap">
                  {vehicle.description}
                </p>
              </div>
            )}

            {/* Dealer Info */}
            {vehicle.dealer && (
              <div className="bg-[#111] border border-white/10 rounded-xl p-5">
                <h3 className="text-sm text-zinc-400 font-semibold tracking-wider uppercase mb-3">
                  Dealer
                </h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    {vehicle.dealer.logoUrl ? (
                      <img
                        src={vehicle.dealer.logoUrl}
                        alt={vehicle.dealer.name}
                        className="w-10 h-10 rounded-full object-cover ring-2 ring-white/10"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-zinc-700 flex items-center justify-center ring-2 ring-white/10">
                        <span className="text-sm font-bold text-zinc-300">
                          {vehicle.dealer.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                    )}
                    <p className="text-white font-semibold text-lg">{vehicle.dealer.name}</p>
                  </div>
                  <p className="text-zinc-400 flex items-center gap-2">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                    {vehicle.dealer.phone}
                  </p>

                  {/* Website URL — only shown for paid subscribers */}
                  {vehicle.dealer.websiteUrl && (
                    <a
                      href={vehicle.dealer.websiteUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 mt-3 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-semibold px-5 py-2.5 rounded-lg transition-all duration-150 active:scale-[0.97] shadow-lg shadow-blue-600/20"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                      </svg>
                      Visit Dealer Website
                    </a>
                  )}
                </div>
              </div>
            )}

            {/* CTA — only enabled if dealer has credit application page */}
            {!isExpired && (
              vehicle.dealer?.websiteUrl ? (
                <a
                  href={vehicle.dealer.websiteUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full"
                >
                  <Button
                    className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 rounded-xl text-lg h-auto transition-all duration-150 active:scale-[0.97] shadow-xl shadow-red-600/20"
                  >
                    APPLY FOR CREDIT →
                  </Button>
                </a>
              ) : (
                <div className="space-y-2">
                  <Button
                    disabled
                    className="w-full bg-zinc-800 text-zinc-500 font-bold py-4 rounded-xl text-lg h-auto cursor-not-allowed"
                  >
                    NO CREDIT APPLICATION AVAILABLE
                  </Button>
                  <p className="text-xs text-zinc-500 text-center">
                    This dealer has not set up a credit application page.
                  </p>
                </div>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
