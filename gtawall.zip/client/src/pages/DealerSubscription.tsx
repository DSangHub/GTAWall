import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { useLocation, useSearch } from "wouter";
import { SEO } from "@/components/SEO";

export default function DealerSubscription() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();
  const searchString = useSearch();
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "yearly">("monthly");

  const { data: profile, isLoading: profileLoading } = trpc.dealer.profile.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const activateMutation = trpc.dealer.activateSubscription.useMutation({
    onSuccess: (data) => {
      if (data.checkoutUrl) {
        toast.info("Redirecting to checkout...", {
          description: "You'll be taken to Stripe to complete your payment.",
        });
        window.open(data.checkoutUrl, "_blank");
      }
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  // Handle success/cancel redirects from Stripe
  useEffect(() => {
    const params = new URLSearchParams(searchString);
    if (params.get("success") === "true") {
      const plan = params.get("plan");
      toast.success("Payment successful!", {
        description: `Your ${plan === "yearly" ? "$500/year" : "$50/month"} subscription is now active. Your website URL will appear on all your listings.`,
      });
    } else if (params.get("canceled") === "true") {
      toast.info("Payment canceled", {
        description: "No charges were made. You can try again anytime.",
      });
    }
  }, [searchString]);

  if (loading || profileLoading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="animate-pulse text-zinc-500">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <h1 className="font-display text-3xl font-bold text-white mb-4">
            Dealer Subscription
          </h1>
          <p className="text-zinc-400 mb-6">Sign in to manage your subscription.</p>
          <a href={getLoginUrl()} className="inline-block bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-3 rounded-xl transition-all">
            Sign In
          </a>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <h1 className="font-display text-3xl font-bold text-white mb-4">
            Register First
          </h1>
          <p className="text-zinc-400 mb-6">Complete your dealer registration before subscribing.</p>
          <Button onClick={() => setLocation("/dealer-signup")} className="bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-3 rounded-xl">
            Register as Dealer
          </Button>
        </div>
      </div>
    );
  }

  const hasActiveSubscription = profile.subscriptionEndDate && new Date(profile.subscriptionEndDate) > new Date();

  const handleActivate = (e: React.FormEvent) => {
    e.preventDefault();

    if (!websiteUrl.trim()) {
      toast.error("Please enter your website URL");
      return;
    }

    // Basic URL validation
    try {
      new URL(websiteUrl);
    } catch {
      toast.error("Please enter a valid URL (e.g. https://www.yoursite.com)");
      return;
    }

    activateMutation.mutate({
      websiteUrl: websiteUrl.trim(),
      plan: selectedPlan,
      origin: window.location.origin,
    });
  };

  return (
    <div className="min-h-screen bg-[#050505] py-16 px-6">
      <SEO
        title="Display Your Website URL — Dealer Subscription | GTA Wall"
        description="Upgrade your GTA Wall dealer account to display your website URL on all your listings. $50/month or $500/year. Drive traffic to your credit application page."
        url="https://www.gtawall.com/dealer-subscription"
      />
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <a href="/" className="inline-block mb-8">
            <img src="/manus-storage/logo_3c487b38.png" alt="GTA WALL" className="h-10 w-auto mx-auto" />
          </a>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">
            Display Your Website
          </h1>
          <p className="text-zinc-400 text-lg max-w-xl mx-auto">
            Get a clickable link to your website on every vehicle listing. Drive traffic directly from GTA Wall to your site.
          </p>
        </div>

        {/* Active subscription status */}
        {hasActiveSubscription && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-6 mb-10 text-center">
            <div className="w-12 h-12 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <svg className="w-6 h-6 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h3 className="text-emerald-400 font-bold text-lg mb-1">Subscription Active</h3>
            <p className="text-zinc-400">
              Your website <span className="text-white font-medium">{profile.websiteUrl}</span> is displayed on all your listings.
            </p>
            <p className="text-zinc-500 text-sm mt-2">
              Expires: {new Date(profile.subscriptionEndDate!).toLocaleDateString()}
            </p>
          </div>
        )}

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {/* Monthly */}
          <button
            onClick={() => setSelectedPlan("monthly")}
            className={`text-left p-6 rounded-2xl border-2 transition-all duration-200 ${
              selectedPlan === "monthly"
                ? "border-red-500 bg-red-500/5"
                : "border-white/10 bg-[#111] hover:border-white/20"
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-zinc-400 text-sm font-medium uppercase tracking-wider">Monthly</span>
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                selectedPlan === "monthly" ? "border-red-500" : "border-zinc-600"
              }`}>
                {selectedPlan === "monthly" && <div className="w-2.5 h-2.5 bg-red-500 rounded-full" />}
              </div>
            </div>
            <div className="mb-3">
              <span className="text-4xl font-bold text-white">$50</span>
              <span className="text-zinc-400 ml-1">/month</span>
            </div>
            <p className="text-zinc-400 text-sm">
              Flexible month-to-month. Cancel anytime. Your website link appears on all your active listings.
            </p>
          </button>

          {/* Yearly */}
          <button
            onClick={() => setSelectedPlan("yearly")}
            className={`text-left p-6 rounded-2xl border-2 transition-all duration-200 relative ${
              selectedPlan === "yearly"
                ? "border-amber-500 bg-amber-500/5"
                : "border-white/10 bg-[#111] hover:border-white/20"
            }`}
          >
            <div className="absolute -top-3 right-4 bg-amber-500 text-black text-xs font-bold px-3 py-1 rounded-full">
              SAVE $100
            </div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-zinc-400 text-sm font-medium uppercase tracking-wider">Yearly</span>
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                selectedPlan === "yearly" ? "border-amber-500" : "border-zinc-600"
              }`}>
                {selectedPlan === "yearly" && <div className="w-2.5 h-2.5 bg-amber-500 rounded-full" />}
              </div>
            </div>
            <div className="mb-3">
              <span className="text-4xl font-bold text-white">$500</span>
              <span className="text-zinc-400 ml-1">/year</span>
            </div>
            <p className="text-zinc-400 text-sm">
              Best value — save $100 vs monthly. Locked-in rate for 12 months. Priority placement.
            </p>
          </button>
        </div>

        {/* URL Input & Checkout */}
        <form onSubmit={handleActivate} className="bg-[#111] border border-white/10 rounded-2xl p-8 max-w-lg mx-auto">
          <h3 className="text-white font-bold text-xl mb-4">Enter Your Credit Application Page URL</h3>
          <p className="text-zinc-400 text-sm mb-4">
            This URL will power the <strong className="text-white">"Apply for Credit"</strong> button on all your vehicle listings. Buyers click it to go directly to your credit application.
          </p>
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 mb-6">
            <p className="text-amber-300 text-xs font-medium flex items-start gap-2">
              <svg className="w-4 h-4 mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>Pro tip: Use your credit application page as the landing page. This converts browsers into buyers by getting them pre-approved before they even visit your lot.</span>
            </p>
          </div>

          <div className="mb-6">
            <Label htmlFor="website-url" className="text-zinc-300 text-sm font-medium">
              Website URL *
            </Label>
            <Input
              id="website-url"
              type="url"
              placeholder="https://www.yourdealership.com"
              value={websiteUrl}
              onChange={(e) => setWebsiteUrl(e.target.value)}
              className="mt-2 bg-[#1a1a1a] border-white/10 text-white placeholder:text-zinc-600 focus:border-red-500 focus:ring-red-500/20 h-12"
            />
          </div>

          <div className="bg-[#0a0a0a] rounded-lg p-4 mb-6">
            <div className="flex justify-between text-sm">
              <span className="text-zinc-400">Plan</span>
              <span className="text-white font-medium">
                {selectedPlan === "monthly" ? "Monthly" : "Yearly"}
              </span>
            </div>
            <div className="flex justify-between text-sm mt-2">
              <span className="text-zinc-400">Price</span>
              <span className="text-emerald-400 font-bold">
                {selectedPlan === "monthly" ? "$50 CAD/month" : "$500 CAD/year"}
              </span>
            </div>
          </div>

          <Button
            type="submit"
            disabled={activateMutation.isPending}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 rounded-xl h-auto text-lg transition-all duration-150 active:scale-[0.97] disabled:opacity-50"
          >
            {activateMutation.isPending
              ? "Redirecting to checkout..."
              : `Subscribe — ${selectedPlan === "monthly" ? "$50/month" : "$500/year"}`}
          </Button>

          <div className="flex items-center justify-center gap-2 mt-4">
            <svg className="w-4 h-4 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <p className="text-xs text-zinc-500">
              Secure payment powered by Stripe. You can test with card 4242 4242 4242 4242.
            </p>
          </div>
        </form>

        {/* Benefits */}
        <div className="mt-16 text-center">
          <h3 className="text-white font-bold text-xl mb-6">Why Display Your Website?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#111] border border-white/10 rounded-xl p-5">
              <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                <svg className="w-5 h-5 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
                </svg>
              </div>
              <h4 className="text-white font-semibold mb-1">1-Click Credit Apps</h4>
              <p className="text-zinc-400 text-sm">Buyers apply for credit directly from your listing — pre-approved before they visit.</p>
            </div>
            <div className="bg-[#111] border border-white/10 rounded-xl p-5">
              <div className="w-10 h-10 bg-emerald-500/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                <svg className="w-5 h-5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <h4 className="text-white font-semibold mb-1">More Inventory Views</h4>
              <p className="text-zinc-400 text-sm">Showcase your full inventory beyond the 3 vehicles on GTA Wall.</p>
            </div>
            <div className="bg-[#111] border border-white/10 rounded-xl p-5">
              <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                <svg className="w-5 h-5 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h4 className="text-white font-semibold mb-1">Build Your Brand</h4>
              <p className="text-zinc-400 text-sm">Establish credibility and drive repeat business to your dealership.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
