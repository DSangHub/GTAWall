import { useState, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { SEO } from "@/components/SEO";

const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_LOGO_SIZE = 2 * 1024 * 1024; // 2MB

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1]); // strip data:... prefix
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function DealerSignup() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [dealerName, setDealerName] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [geocoding, setGeocoding] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: profile, isLoading: profileLoading } = trpc.dealer.profile.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const registerMutation = trpc.dealer.register.useMutation({
    onSuccess: () => {
      // If logo was selected, upload it after registration
      if (logoFile) {
        uploadLogo();
      } else {
        toast.success("Dealer registration complete!", {
          description: "You can now post up to 3 vehicles on the GTA Wall.",
        });
        setLocation("/dashboard");
      }
    },
    onError: (error) => {
      toast.error(error.message || "Registration failed");
    },
  });

  const uploadLogoMutation = trpc.dealer.uploadLogo.useMutation({
    onSuccess: () => {
      toast.success("Dealer registration complete!", {
        description: "You can now post up to 3 vehicles on the GTA Wall.",
      });
      setLocation("/dashboard");
    },
    onError: () => {
      // Registration succeeded but logo upload failed — still redirect
      toast.success("Registered! Logo upload failed — you can retry from your dashboard.");
      setLocation("/dashboard");
    },
  });

  const uploadLogo = async () => {
    if (!logoFile) return;
    try {
      const base64 = await readFileAsBase64(logoFile);
      uploadLogoMutation.mutate({
        imageBase64: base64,
        mimeType: logoFile.type,
      });
    } catch {
      toast.success("Registered! Logo upload failed — you can retry from your dashboard.");
      setLocation("/dashboard");
    }
  };

  const handleLogoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      toast.error("Please select a JPG, PNG, or WebP image");
      return;
    }
    if (file.size > MAX_LOGO_SIZE) {
      toast.error("Logo must be under 2MB");
      return;
    }

    setLogoFile(file);
    setLogoPreview(URL.createObjectURL(file));
  };

  if (loading || profileLoading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="animate-pulse text-zinc-500">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-6">
          <h1 className="font-display text-3xl font-bold text-white mb-4">
            Dealer Registration
          </h1>
          <p className="text-zinc-400 mb-6">
            Sign in first, then complete your dealer profile to start posting vehicles.
          </p>
          <a
            href={getLoginUrl()}
            className="inline-block bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-3 rounded-xl transition-all"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  // Already registered — redirect to dashboard
  if (profile) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-6">
          <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-8 h-8 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="font-display text-3xl font-bold text-white mb-4">
            Already Registered
          </h1>
          <p className="text-zinc-400 mb-6">
            You're registered as <span className="text-white font-semibold">{profile.dealerName}</span>. You can post up to {profile.maxVehicles} vehicles.
          </p>
          <div className="flex gap-3 justify-center">
            <a
              href="/dashboard"
              className="inline-block bg-red-600 hover:bg-red-700 text-white font-bold px-6 py-2.5 rounded-lg transition-all"
            >
              Go to Dashboard
            </a>
            <a
              href="/"
              className="inline-block border border-white/20 text-white font-medium px-6 py-2.5 rounded-lg transition-all hover:bg-white/5"
            >
              Back to Wall
            </a>
          </div>
        </div>
      </div>
    );
  }

  const geocodeAddress = async (addr: string): Promise<{ lat: number; lng: number } | null> => {
    try {
      const response = await fetch(
        `/api/geocode?address=${encodeURIComponent(addr)}`
      );
      if (!response.ok) return null;
      const data = await response.json();
      if (data.lat && data.lng) return { lat: data.lat, lng: data.lng };
      return null;
    } catch {
      return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!dealerName.trim() || !address.trim() || !phone.trim()) {
      toast.error("Please fill in all fields");
      return;
    }

    if (phone.length < 7) {
      toast.error("Please enter a valid phone number");
      return;
    }

    // Geocode the address to get lat/lng
    setGeocoding(true);
    const coords = await geocodeAddress(address.trim());
    setGeocoding(false);

    registerMutation.mutate({
      dealerName: dealerName.trim(),
      address: address.trim(),
      phone: phone.trim(),
      ...(coords ? { latitude: coords.lat, longitude: coords.lng } : {}),
    });
  };

  const isPending = registerMutation.isPending || uploadLogoMutation.isPending || geocoding;

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center py-16 px-6">
      <SEO
        title="Dealer Registration — Post Vehicles on GTA Wall"
        description="Register as a dealer on GTA Wall. Post up to 3 vehicles going to auction and reach buyers before the auction block. Free to join."
        url="https://www.gtawall.com/dealer-signup"
      />
      <div className="w-full max-w-lg">
        {/* Header */}
        <div className="text-center mb-10">
          <a href="/" className="inline-block mb-8">
            <img
              src="/manus-storage/logo_3c487b38.png"
              alt="GTA WALL"
              className="h-10 w-auto mx-auto"
            />
          </a>
          <h1 className="font-display text-4xl font-bold text-white mb-3">
            Dealer Registration
          </h1>
          <p className="text-zinc-400">
            Complete your profile to start posting vehicles on the GTA Wall.
            <br />
            <span className="text-emerald-400 font-semibold">Free — post up to 3 vehicles.</span>
          </p>
        </div>

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="bg-[#111] border border-white/10 rounded-2xl p-8 space-y-6"
        >
          {/* Logo Upload */}
          <div>
            <Label className="text-zinc-300 text-sm font-medium">
              Dealer Logo (optional)
            </Label>
            <div className="mt-2 flex items-center gap-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="w-16 h-16 rounded-full bg-[#1a1a1a] border-2 border-dashed border-white/20 flex items-center justify-center cursor-pointer hover:border-red-500/50 transition-colors overflow-hidden"
              >
                {logoPreview ? (
                  <img src={logoPreview} alt="Logo preview" className="w-full h-full object-cover" />
                ) : (
                  <svg className="w-6 h-6 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z" />
                  </svg>
                )}
              </div>
              <div className="flex-1">
                <p className="text-xs text-zinc-500">
                  Upload your business logo. JPG, PNG or WebP, max 2MB.
                </p>
                {logoFile && (
                  <p className="text-xs text-emerald-400 mt-1">{logoFile.name}</p>
                )}
              </div>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={handleLogoSelect}
              className="hidden"
            />
          </div>

          <div>
            <Label htmlFor="dealer-name" className="text-zinc-300 text-sm font-medium">
              Dealer / Business Name *
            </Label>
            <Input
              id="dealer-name"
              placeholder="e.g. GTA Auto Sales"
              value={dealerName}
              onChange={(e) => setDealerName(e.target.value)}
              className="mt-2 bg-[#1a1a1a] border-white/10 text-white placeholder:text-zinc-600 focus:border-red-500 focus:ring-red-500/20 h-12"
            />
          </div>

          <div>
            <Label htmlFor="dealer-address" className="text-zinc-300 text-sm font-medium">
              Business Address *
            </Label>
            <Input
              id="dealer-address"
              placeholder="e.g. 123 Main St, Toronto, ON M5V 1A1"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="mt-2 bg-[#1a1a1a] border-white/10 text-white placeholder:text-zinc-600 focus:border-red-500 focus:ring-red-500/20 h-12"
            />
          </div>

          <div>
            <Label htmlFor="dealer-phone" className="text-zinc-300 text-sm font-medium">
              Phone Number *
            </Label>
            <Input
              id="dealer-phone"
              type="tel"
              placeholder="e.g. (416) 555-0123"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="mt-2 bg-[#1a1a1a] border-white/10 text-white placeholder:text-zinc-600 focus:border-red-500 focus:ring-red-500/20 h-12"
            />
          </div>

          {/* Info box */}
          <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-lg p-4">
            <p className="text-emerald-400 text-sm font-medium mb-1">What you get:</p>
            <ul className="text-zinc-400 text-sm space-y-1">
              <li>• Post up to <span className="text-white font-semibold">3 vehicles</span> on the GTA Wall</li>
              <li>• Live countdown timers visible to all buyers</li>
              <li>• Receive offers directly before auction date</li>
              <li>• Zero listing fees — completely free</li>
            </ul>
          </div>

          <Button
            type="submit"
            disabled={isPending}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 rounded-xl transition-all duration-150 active:scale-[0.97] h-auto text-lg disabled:opacity-50"
          >
            {isPending ? "Registering..." : "Complete Registration"}
          </Button>

          <p className="text-xs text-zinc-600 text-center">
            By registering, you agree to the GTA Wall terms of service.
          </p>
        </form>
      </div>
    </div>
  );
}
