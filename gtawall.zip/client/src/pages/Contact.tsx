import { SEO } from "@/components/SEO";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export default function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("general");
  const [message, setMessage] = useState("");

  const submitContact = trpc.contact.submit.useMutation({
    onSuccess: () => {
      toast.success("Message sent! We'll get back to you soon.");
      setName("");
      setEmail("");
      setSubject("general");
      setMessage("");
    },
    onError: (err: { message?: string }) => {
      toast.error(err.message || "Failed to send message. Please try again.");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      toast.error("Please fill in all required fields.");
      return;
    }
    submitContact.mutate({ name: name.trim(), email: email.trim(), subject, message: message.trim() });
  };

  return (
    <div className="min-h-screen bg-[#050505]">
      <SEO
        title="Contact Us — GTA Wall"
        description="Get in touch with GTA Wall. Questions about listings, dealer registration, or the platform? We're here to help."
        url="https://www.gtawall.com/contact"
      />

      {/* Header */}
      <header className="bg-[#0a0a0a] border-b border-white/5 py-4 px-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <a href="/">
            <img
              src="/manus-storage/logo_3c487b38.png"
              alt="GTA WALL"
              className="h-9 w-auto"
            />
          </a>
          <a
            href="/"
            className="text-zinc-400 hover:text-white text-sm transition-colors"
          >
            ← Back to Wall
          </a>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-2 gap-16">
          {/* Left: Info */}
          <div>
            <h1 className="font-display text-4xl font-bold text-white mb-4">
              Contact Us
            </h1>
            <p className="text-zinc-400 leading-relaxed mb-8">
              Have a question about a listing, need help with dealer registration, or want to report
              an issue? Fill out the form and we'll get back to you as soon as possible.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <div>
                  <p className="text-white font-medium text-sm">Email</p>
                  <p className="text-zinc-500 text-sm">support@gtawall.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <div>
                  <p className="text-white font-medium text-sm">Location</p>
                  <p className="text-zinc-500 text-sm">Greater Toronto Area, Ontario, Canada</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <p className="text-white font-medium text-sm">Response Time</p>
                  <p className="text-zinc-500 text-sm">Usually within 24 hours</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Form */}
          <div>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="text-xs text-zinc-500 font-semibold uppercase tracking-wider block mb-1.5">
                  Name <span className="text-red-400">*</span>
                </label>
                <Input
                  type="text"
                  placeholder="Your full name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="bg-[#0a0a0a] border-white/10 text-white placeholder:text-zinc-600 focus:border-red-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-zinc-500 font-semibold uppercase tracking-wider block mb-1.5">
                  Email <span className="text-red-400">*</span>
                </label>
                <Input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-[#0a0a0a] border-white/10 text-white placeholder:text-zinc-600 focus:border-red-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-zinc-500 font-semibold uppercase tracking-wider block mb-1.5">
                  Subject
                </label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full h-10 px-3 bg-[#0a0a0a] border border-white/10 rounded-md text-white text-sm focus:border-red-500 focus:outline-none appearance-none cursor-pointer"
                >
                  <option value="general">General Inquiry</option>
                  <option value="dealer">Dealer Registration</option>
                  <option value="listing">Listing Issue</option>
                  <option value="technical">Technical Support</option>
                  <option value="feedback">Feedback</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-zinc-500 font-semibold uppercase tracking-wider block mb-1.5">
                  Message <span className="text-red-400">*</span>
                </label>
                <textarea
                  placeholder="How can we help you?"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={5}
                  className="w-full px-3 py-2 bg-[#0a0a0a] border border-white/10 rounded-md text-white text-sm placeholder:text-zinc-600 focus:border-red-500 focus:outline-none resize-none"
                  required
                />
              </div>

              <Button
                type="submit"
                disabled={submitContact.isPending}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold h-11 transition-all active:scale-[0.97]"
              >
                {submitContact.isPending ? (
                  <span className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Sending...
                  </span>
                ) : (
                  "Send Message"
                )}
              </Button>
            </form>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-8 px-6 mt-16">
        <div className="max-w-4xl mx-auto text-center text-zinc-600 text-sm">
          © {new Date().getFullYear()} GTA Wall — Going To Auction. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
