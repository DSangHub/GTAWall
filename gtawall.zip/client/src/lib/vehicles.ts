/**
 * Vehicle type matching the database schema returned by tRPC.
 * Used across all frontend components.
 */
export interface Vehicle {
  id: number;
  dealerId: number;
  title: string;
  price: number;
  auctionDeadline: number; // UTC timestamp in ms
  imageUrl: string | null;
  mileage: string | null;
  condition: string | null;
  description: string | null;
  vin: string | null;
  year: number | null;
  make: string | null;
  model: string | null;
  color: string | null;
  isPremium: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  /** Dealer's credit application page URL — only set if subscription is active */
  dealerWebsiteUrl?: string | null;
  /** Dealer business name */
  dealerName?: string | null;
  /** Dealer logo/avatar URL */
  dealerLogoUrl?: string | null;
  /** Dealer location latitude */
  dealerLatitude?: number | null;
  /** Dealer location longitude */
  dealerLongitude?: number | null;
}

/** Placeholder image for vehicles without an uploaded photo */
export const PLACEHOLDER_IMAGE =
  "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=600&h=400&fit=crop";

/** Sample vehicles for the initial wall when DB is empty */
export function getInitialVehicles(): Vehicle[] {
  const now = Date.now();
  return [
    {
      id: -1,
      dealerId: 0,
      title: "2022 Ford F-150 XLT",
      price: 28900,
      auctionDeadline: now + 5 * 86400000,
      imageUrl: "/manus-storage/card-ford-f150_e49259d5.jpg",
      isPremium: true,
      isActive: true,
      mileage: "32,400 mi",
      condition: "Excellent",
      description: null,
      vin: null,
      year: 2022,
      make: "Ford",
      model: "F-150 XLT",
      color: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: -2,
      dealerId: 0,
      title: "2023 Toyota Camry SE",
      price: 21499,
      auctionDeadline: now + 2 * 86400000,
      imageUrl: "/manus-storage/card-toyota-camry_10629bf7.jpg",
      isPremium: false,
      isActive: true,
      mileage: "18,200 mi",
      condition: "Like New",
      description: null,
      vin: null,
      year: 2023,
      make: "Toyota",
      model: "Camry SE",
      color: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: -3,
      dealerId: 0,
      title: "2021 Chevy Silverado",
      price: 32750,
      auctionDeadline: now + 8 * 86400000,
      imageUrl: "/manus-storage/card-chevy-silverado_a9052618.jpg",
      isPremium: true,
      isActive: true,
      mileage: "45,100 mi",
      condition: "Very Good",
      description: null,
      vin: null,
      year: 2021,
      make: "Chevrolet",
      model: "Silverado",
      color: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: -4,
      dealerId: 0,
      title: "2020 Honda Civic Sport",
      price: 18500,
      auctionDeadline: now + 3 * 86400000,
      imageUrl: "https://images.unsplash.com/photo-1606611013016-969c19ba27bb?w=600&h=400&fit=crop",
      isPremium: false,
      isActive: true,
      mileage: "52,800 mi",
      condition: "Good",
      description: null,
      vin: null,
      year: 2020,
      make: "Honda",
      model: "Civic Sport",
      color: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: -5,
      dealerId: 0,
      title: "2022 RAM 1500 Big Horn",
      price: 36200,
      auctionDeadline: now + 6 * 86400000,
      imageUrl: "https://images.unsplash.com/photo-1559416523-140ddc3d238c?w=600&h=400&fit=crop",
      isPremium: true,
      isActive: true,
      mileage: "28,900 mi",
      condition: "Excellent",
      description: null,
      vin: null,
      year: 2022,
      make: "RAM",
      model: "1500 Big Horn",
      color: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: -6,
      dealerId: 0,
      title: "2021 Nissan Altima SR",
      price: 19800,
      auctionDeadline: now + 1 * 86400000,
      imageUrl: "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=600&h=400&fit=crop",
      isPremium: false,
      isActive: true,
      mileage: "41,300 mi",
      condition: "Good",
      description: null,
      vin: null,
      year: 2021,
      make: "Nissan",
      model: "Altima SR",
      color: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];
}
