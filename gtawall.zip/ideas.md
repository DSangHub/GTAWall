# GTA Wall — Design Brainstorm

## Three Approaches

### 1. Midnight Auction House
- **Very Brief Intro**: A dark, cinematic automotive aesthetic inspired by luxury car showrooms at night. High contrast, dramatic lighting, urgency-driven UI with countdown timers as the focal point.
- **Probability**: 0.07

### 2. Neon Garage
- **Very Brief Intro**: Retro-futuristic neon-lit garage vibe with glowing accents, cyberpunk-inspired color pops, and industrial textures. Bold and attention-grabbing.
- **Probability**: 0.04

### 3. Clean Dealership
- **Very Brief Intro**: Minimalist, professional dealership aesthetic with a white/light theme, clean typography, and subtle automotive cues. Trust-focused and corporate.
- **Probability**: 0.03

---

## Chosen Approach: Midnight Auction House

### Design Movement
Dark luxury automotive — inspired by high-end car showroom photography, Barrett-Jackson auction aesthetics, and premium automotive brand websites (Porsche, Audi configurators).

### Core Principles
1. **Urgency through contrast** — Red countdown elements pop against the near-black canvas, creating visual tension
2. **Cinematic depth** — Layered gradients, subtle glows, and image overlays create a sense of physical space
3. **Automotive authority** — Bold condensed typography and structured grid layouts convey professionalism
4. **Premium hierarchy** — Gold/amber accents for featured listings create clear visual tiers

### Color Philosophy
- **Primary canvas**: Deep zinc/charcoal (#09090b to #18181b) — evokes a nighttime lot
- **Action red**: #dc2626 — urgency, CTAs, countdown timers. This is the heartbeat color.
- **Money green**: #4ade80 — prices, positive signals
- **Premium gold**: #eab308 — featured listings, VIP tier
- **Neutral text**: White to zinc-400 gradient for hierarchy

### Layout Paradigm
Full-bleed hero with parallax depth, followed by a dense card grid that feels like a "wall" of inventory. Cards are the primary content unit — each is a self-contained auction listing with its own countdown clock. The wall scrolls infinitely, creating the feeling of endless inventory.

### Signature Elements
1. **Live countdown timers** — Monospace red digits ticking down on every card, creating urgency
2. **Premium glow cards** — Gold-bordered cards with ambient glow for featured listings
3. **Dark gradient overlays** — Cinematic gradients over imagery that fade to the dark canvas

### Interaction Philosophy
Interactions should feel immediate and mechanical — like flipping switches on a dashboard. Button presses compress slightly (scale 0.97), modals slide up from below like a car lift. Hover states reveal additional info like mileage/condition.

### Animation
- Card entrance: stagger fade-up with 50ms delay between cards
- Countdown timers: subtle pulse on the seconds digit
- Hero: slow Ken Burns zoom on the background image
- Buttons: 150ms scale(0.97) on press, 200ms ease-out release
- Modal: slide up from bottom with backdrop blur, 250ms

### Typography System
- **Display/Headlines**: "Oswald" (condensed, bold) — automotive authority
- **Body/UI**: "Inter" weight 400-600 — clean readability
- **Monospace/Timers**: "JetBrains Mono" — countdown digits

### Brand Essence
GTA Wall is the pre-auction marketplace where dealers offload inventory and buyers grab deals before cars hit the block — fast, transparent, urgent.
**Personality**: Urgent, trustworthy, no-nonsense.

### Brand Voice
Headlines are punchy and direct. CTAs create FOMO. No fluff.
- "5 days. Then it's gone."
- "Skip the auction. Buy direct."

### Wordmark & Logo
Bold "GTA WALL" with a speed-line car silhouette integrated above the text. "GOING TO AUCTION" as a subtitle. Red and white on dark backgrounds.

### Signature Brand Color
**Action Red (#dc2626)** — unmistakably urgent, automotive, and commanding attention against the dark canvas.

## Style Decisions

- Inventory cards must read as live auction instruments first and dealership listings second: countdowns, offer actions, and urgency cues should be visually dominant on every card.
- GTA Wall's wordmark must be treated as a signature asset: bold red/white mark with the speed-line car silhouette and "GOING TO AUCTION" subtitle should be clearly legible wherever the brand appears.
- Vehicle imagery should be unified by dark cinematic grading, strong contrast, and auction/showroom atmosphere; avoid bright mixed dealership-photo styling unless it is heavily integrated into the dark visual system.
- Copy voice stays terse, urgent, and FOMO-driven throughout. No generic SaaS language.
