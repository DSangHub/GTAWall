import "dotenv/config";
import express, { type Express } from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { createStripeWebhookRouter } from "../stripe/index";
import { expiringNotificationsHandler } from "../scheduled/expiringNotifications";
import { sitemapHandler, robotsHandler } from "../sitemap";
import { geocodeHandler } from "../geocode";

/**
 * Build the Express application with every dynamic (non-static) route.
 *
 * This intentionally does NOT serve the built client or call `listen()`, so it
 * can be reused in two contexts:
 *   - the standalone Node server (server/_core/index.ts), which adds Vite /
 *     static serving and binds a port, and
 *   - the Vercel serverless function (api/index.ts), where Vercel's CDN serves
 *     the static client and this app only handles dynamic routes.
 */
export function createApp(): Express {
  const app = express();

  // Stripe webhook must be registered BEFORE express.json() so the raw body is
  // available for signature verification.
  app.use("/api/stripe", createStripeWebhookRouter());

  // Scheduled endpoint. `app.all` so it responds to Vercel Cron (which issues a
  // GET) as well as manual POST triggers. Registered before the global body
  // parser to preserve the original ordering.
  app.all(
    "/api/scheduled/expiring-notifications",
    express.json(),
    expiringNotificationsHandler
  );

  // Global body parsers with a larger limit for file uploads.
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerStorageProxy(app);
  registerOAuthRoutes(app);

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  // SEO
  app.get("/sitemap.xml", sitemapHandler);
  app.get("/robots.txt", robotsHandler);

  // Geocoding API for dealer address lookup
  app.get("/api/geocode", geocodeHandler);

  return app;
}
