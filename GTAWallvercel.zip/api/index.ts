import { createApp } from "../server/_core/app";

/**
 * Vercel serverless entry point.
 *
 * An Express application instance is itself a `(req, res)` request handler, so
 * exporting it as the default export lets `@vercel/node` invoke it directly.
 * The app is created once per warm function instance (module scope) and reused
 * across invocations.
 *
 * Routing to this function is configured in `vercel.json`: requests under
 * `/api/*`, `/manus-storage/*`, `/sitemap.xml` and `/robots.txt` are rewritten
 * here while the original request URL is preserved, so Express's own routing
 * continues to work unchanged. All other paths are served as static assets /
 * the SPA shell by Vercel's CDN.
 */
const app = createApp();

export default app;
