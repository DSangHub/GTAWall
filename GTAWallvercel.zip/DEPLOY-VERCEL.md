# Deploying GTAWall to Vercel

This app was originally written as a single long-running Express server
(`node dist/index.js`) that serves both the API and the built client. Vercel
runs static assets on its CDN and code as **stateless serverless functions** —
there is no persistent process. These files adapt the app to that model:

| File | Purpose |
| --- | --- |
| `server/_core/app.ts` | `createApp()` — builds the Express app with all dynamic routes, no `listen()` and no static serving. Shared by both runtimes. |
| `server/_core/index.ts` | Standalone server for local dev (`pnpm dev`) and non-Vercel hosts (`pnpm start`). Adds Vite / static serving + binds a port. Unused on Vercel. |
| `api/index.ts` | Vercel serverless entry. Exports the Express app as the default handler. |
| `vercel.json` | Builds the client to `dist/public` (served by the CDN), rewrites dynamic paths to the function, falls back to `index.html` for SPA routes, and registers the cron. |

## How routing works

Vercel checks the filesystem first, then applies `rewrites` in order:

- `/assets/*`, `/index.html`, etc. → served statically from `dist/public`.
- `/api/*`, `/manus-storage/*`, `/sitemap.xml`, `/robots.txt` → rewritten to the
  `api/index.ts` function. The **original URL is preserved**, so Express's own
  routing (`/api/trpc/...`, `/api/oauth/callback`, `/manus-storage/<key>`, …)
  works unchanged.
- Everything else → `index.html`, so client-side (wouter) routes resolve.

## Before it will work: set environment variables

In the Vercel project settings add every variable the server reads (database
URL, Stripe keys, OAuth / SDK credentials, AWS S3, `FORGE_API_URL` /
`FORGE_API_KEY` for the storage proxy, geocoding key, etc.). Locally these come
from `.env`; on Vercel they must be configured in the dashboard. `NODE_ENV` is
set to `production` by Vercel automatically.

## Caveats that still need your attention

These are the "stateful pieces" that don't map cleanly onto serverless. The
build compiles and deploys without them, but verify each against your setup:

1. **Stripe webhook raw body.** Signature verification needs the *unparsed*
   request body. The webhook router is mounted before `express.json()`, which is
   correct, but Vercel's Node runtime may buffer/parse the body before Express
   sees it. After deploying, send a test event and confirm the signature check
   passes. If it fails, split the webhook into its own function
   (`api/stripe/webhook.ts`) with body parsing disabled and read the raw stream
   there.

2. **Cron authentication.** `vercel.json` schedules a daily GET to
   `/api/scheduled/expiring-notifications`. That handler currently calls
   `sdk.authenticateRequest(req)`, which expects a logged-in user session — a
   cron request has none, so it will 401 as written. Vercel sends cron requests
   with an `Authorization: Bearer $CRON_SECRET` header; gate the handler on that
   secret (set `CRON_SECRET` in project settings) instead of user auth when the
   request comes from the scheduler. Adjust the `schedule` (currently `0 12 * * *`
   = 12:00 UTC daily) as needed.

3. **No background/in-process work.** A serverless function only runs for the
   duration of a request. Any interval timers, heartbeats, warm caches, or
   in-memory state from the long-running server will not persist between
   invocations. Move recurring work to Vercel Cron and keep all state in the
   database / external stores.

4. **Function limits.** Default execution time and payload limits apply. The
   body parser here allows 50mb uploads, but Vercel has its own request-size
   limits per plan — large uploads should go directly to S3 via presigned URLs
   (the storage proxy already points that way) rather than through the function.

## Alternative

If these serverless constraints are more trouble than they're worth, this app
runs as-is on any host that keeps a Node process alive — Render, Railway, or
Fly.io — with build command `pnpm build` and start command `pnpm start`. No
code changes needed there.
